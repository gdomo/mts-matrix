import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

public class BidirectionalSparseMatrix {
    private final List<Point> pointsByRows;
    private final SortedSet<Point> pointsByColumns;
    private final int rows;
    private final int columns;


    /**
     * @param stream Первый элемент - количество строк, второй количество столбцов.
     *               Далее - элементы матрицы слева-направо и сверху-вниз. Null не допускается.
     *               Stream не должен быть parallel
     */
    public BidirectionalSparseMatrix(Stream<Integer> stream) {
        final AtomicInteger streamCounter = new AtomicInteger(0);
        final int[] rowsColumns = new int[2];
//        final SortedSet<Point> pointsByRows = new TreeSet<>((o1, o2) -> {
//            if (o1.row == o2.row) {
//                return Integer.compare(o1.column, o2.column);
//            } else {
//                return Integer.compare(o1.row, o2.row);
//            }
//        });
        final List<Point> pointsByRows = new ArrayList<>();
        final SortedSet<Point> pointsByColumns = new TreeSet<>(BidirectionalSparseMatrix::compareByRows);
        stream
                .map(value -> new Point(streamCounter.getAndIncrement(), value, 0))
                .forEach(countedValue -> {
                    int count = countedValue.getColumn(); //некрасиво, но ладно
                    final int value = countedValue.getRow();
                    switch (count) {
                        case 0: {
                            rowsColumns[0] = value;
                            break;
                        }
                        case 1: {
                            rowsColumns[1] = value;
                            break;
                        }
                        default: {
                            if (value != 0) {
                                count = count - 2; //теперь count - это номер элемента с матрице, а не стриме
                                final Point point = new Point(count % rowsColumns[1], count / rowsColumns[1], value);
                                pointsByRows.add(point);
                                pointsByColumns.add(point);
                            }
                            break;
                        }
                    }
                });
        if (streamCounter.get() < 2) {
            throw new IllegalArgumentException();
        }
        this.rows = rowsColumns[0];
        this.columns = rowsColumns[1];
        this.pointsByColumns = Collections.unmodifiableSortedSet(pointsByColumns);
//        this.pointsByRows = Collections.unmodifiableSortedSet(pointsByRows);
        this.pointsByRows = Collections.unmodifiableList(pointsByRows);
    }

    public BidirectionalSparseMatrix(List<Point> pointsByRows, int rows, int columns) {
        this.pointsByRows = Collections.unmodifiableList(new ArrayList<>(pointsByRows));
        this.rows = rows;
        this.columns = columns;

        final SortedSet<Point> pointsByColumns = new TreeSet<>(BidirectionalSparseMatrix::compareByRows);
        pointsByColumns.addAll(pointsByRows);
        this.pointsByColumns = Collections.unmodifiableSortedSet(pointsByColumns);
    }

    private static int compareByRows(Point p1, Point p2) {
        if (p1.getColumn() == p2.getColumn()) {
            return Integer.compare(p1.getRow(), p2.getRow());
        } else {
            return Integer.compare(p1.getColumn(), p2.getColumn());
        }
    }

    public Stream<Integer> toStream() {
        final AtomicReference<Point> previous = new AtomicReference<>(null);
        return Stream.of(
                Stream.of(rows, columns),
                pointsByRows.stream().flatMap(point -> {
                    final Stream<Integer> stream = Stream.concat(
                            Optional.ofNullable(previous.get())
                                    .map(previousPoint -> Stream.generate(() -> 0)
                                            .limit((point.getRow() - previousPoint.getRow()) * columns + point.getColumn()  - previousPoint.getColumn() -1))
                                    .orElse(Stream.empty()),
                            Stream.of(point.getValue()));
                    previous.set(point);
                    return stream;
                }),
                Stream.generate(() -> 0).limit(Optional.ofNullable(previous.get()).map(previousPoint -> (rows - previousPoint.getRow()) * columns - previousPoint.getColumn() - 1).orElse(rows * columns)))
                .flatMap(stream -> stream);
    }

    public int getRows() {
        return rows;
    }

    public int getColumns() {
        return columns;
    }

    public List<Point> getPointsByRows() {
        return pointsByRows;
    }

    public SortedSet<Point> getPointsByColumns() {
        return pointsByColumns;
    }
}
