import java.util.*;
import java.util.stream.Stream;

public class BidirectionalSparseMatrixSupport implements SparseMatrixSupport<BidirectionalSparseMatrix> {
    @Override
    public Stream<Integer> toStream(BidirectionalSparseMatrix matrix) {
        return matrix.toStream();
    }

    @Override
    public BidirectionalSparseMatrix fromStream(Stream<Integer> stream) {
        return new BidirectionalSparseMatrix(stream);
    }

    @Override
    public BidirectionalSparseMatrix multiply(BidirectionalSparseMatrix first, BidirectionalSparseMatrix second) {
        if (first.getColumns() != second.getRows()) {
            throw new IllegalArgumentException();
        }
        final ArrayList<Point> pointsByRows = new ArrayList<>();
        final List<Point> firstByRows = first.getPointsByRows();
        final SortedSet<Point> secondByColumns = second.getPointsByColumns();
        if (firstByRows.size() == 0 || secondByColumns.size() == 0) {
            return new BidirectionalSparseMatrix(pointsByRows, first.getRows(), second.getColumns());
        }
        final Iterator<Point> rowIterator = firstByRows.iterator();
        Point rowPoint = rowIterator.next();
        int currentRow = rowPoint.getRow();
        final ArrayList<Point> rowPoints = new ArrayList<>();
        rowPoints.add(rowPoint);
        while (rowIterator.hasNext()) {
            rowPoint = rowIterator.next();
            if (!rowIterator.hasNext()) {
                rowPoints.add(rowPoint);
            }
            if (rowPoint.getRow() != currentRow || !rowIterator.hasNext()) {
                final Iterator<Point> columnIterator = secondByColumns.iterator();
                Point columnPoint = columnIterator.next();
                int currentColumn = columnPoint.getColumn();
                final ArrayList<Point> columnPoints = new ArrayList<>();
                columnPoints.add(columnPoint);
                while (columnIterator.hasNext()) {
                    columnPoint = columnIterator.next();
                    if (!columnIterator.hasNext()) {
                        columnPoints.add(columnPoint);
                    }
                    if (columnPoint.getColumn() != currentColumn || !columnIterator.hasNext()) {
                        final int product = multiply(rowPoints, columnPoints);
                        if (product != 0) {
                            pointsByRows.add(new Point(currentColumn, currentRow, product));
                        }
                        columnPoints.clear();
                        currentColumn = columnPoint.getColumn();
                    }
                    if (columnPoint.getColumn() == currentColumn) {
                        columnPoints.add(columnPoint);
                    }
                }
                rowPoints.clear();
                currentRow = rowPoint.getRow();
            }
            if (rowPoint.getRow() == currentRow) {
                rowPoints.add(rowPoint);
            }
        }

        return new BidirectionalSparseMatrix(pointsByRows, first.getRows(), second.getColumns());
    }

    private int multiply(Collection<Point> row, Collection<Point> column) {
        if (row.size() == 0 || column.size() == 0) {
            return 0;
        }
        int res = 0;
        final Iterator<Point> rowIterator = row.iterator();
        final Iterator<Point> columnIterator = column.iterator();
        Point a = rowIterator.next();
        Point b = columnIterator.next();
        while (true) {
            if (a.getColumn() < b.getRow()) {
                if (rowIterator.hasNext()) {
                    a = rowIterator.next();
                } else {
                    break;
                }
            } else if (a.getColumn() > b.getRow()) {
                if (columnIterator.hasNext()) {
                    b = columnIterator.next();
                } else {
                    break;
                }
            } else {
                res += a.getValue() * b.getValue();
                if (rowIterator.hasNext() && columnIterator.hasNext()) {
                    a = rowIterator.next();
                    b = columnIterator.next();
                } else {
                    break;
                }
            }
        }
        return res;
    }
}
